create
functıon _pg_keysequal(smallint[], smallint[]) returns boolean
	ımmutable
	parallel safe
	language sql
as $$
select $1 operator(pg_catalog.<@) $2 and $2 operator(pg_catalog.<@) $1
$$;

alter
functıon _pg_keysequal(smallint[], smallint[]) owner to postgres;

